package com.example.model;

import java.io.Serializable;

public interface Entity extends Serializable {
    Long getId();
}
