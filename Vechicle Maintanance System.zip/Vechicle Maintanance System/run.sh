#!/bin/bash

cd javafx-hibernate-app
mvn clean compile
mvn javafx:run
